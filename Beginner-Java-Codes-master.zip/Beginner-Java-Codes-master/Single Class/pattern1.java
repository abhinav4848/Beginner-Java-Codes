//Example of pattern
public class pattern1
{
public static void main(String args[])
{
int a,b;
for(a=1;a<=9;a++)
{
for(b=1;b<=a;b++)
System.out.print(b);
System.out.println();
}
}
}