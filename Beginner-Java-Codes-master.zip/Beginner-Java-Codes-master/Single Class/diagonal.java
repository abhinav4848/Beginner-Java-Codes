//To find the diagonal of a Rectangle using assignment statement. Nos. Given before.
public class diagonal
{
public static void main(String args[])
{
int l,b;
double d;d=0;
l=25;b=20;
d=Math.sqrt(l*l+b*b);
System.out.println("The Diagonal of rectangle with Length=25, Breadth=20 ="+d);
}
}