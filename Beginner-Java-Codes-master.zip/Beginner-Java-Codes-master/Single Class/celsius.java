//Converting temp in Farenheit by using assignment statement. Nos. Mentioned Before.
public class celsius
{
    public static void main(String args[])
    {
        int c;
        float f;f=0;
        c=37;
        f=(9*c/5+32);
        System.out.println("37 degree Celsius in Farenheit="+f);
    }
}