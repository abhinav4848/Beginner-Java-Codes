//Finding the area and perimeter of a rectangle. Nos. Mentioned from before.
public class rectangle
{
public static void main(String args[])
{
int l,b,ar,p;ar=0;p=0;
l=25;b=20;
ar=l*b;
p=2*(l+b);
System.out.println("Length=25, Breadth=20.");
System.out.println("The Area of The Rectangle is="+ar);
System.out.println("The Perimeter of The Rectangle is="+p);
}
}