//to find the sum of all natural nos. from 1 to 10
public class natural
{
    public static void main(String args[])
    {
        int a,s; s=0;
        for(a=1;a<=10;a++)
        s=s+a;
        System.out.print("The sum of nos. from 1 to 10 is:"+s);
    }
}