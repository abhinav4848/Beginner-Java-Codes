//Illustration for different mathematical functions.Numbers mentioned from before.
public class maths
{
public static void main(String args[])
{
    double m=3.8;
    double n=8.57;
    System.out.println("The Output of The Following Mathematical Functions are:\n");
    System.out.println("Square root="+Math.sqrt(m));
    System.out.println("Minimum="+Math.min(m,n));
    System.out.println("Maximum="+Math.max(m,n));
    System.out.println("6.25 Raised to the power 3="+Math.pow(m,3));
    System.out.println("Log of(6.25)10="+Math.log(m));
    System.out.println("Absolute Value of (6.25-8.57)="+Math.abs(m-n));
    System.out.println("Rounded Value of 6.25="+Math.round(m));
    System.out.println("Rounded value of 6.25 down to nearest Integer="+Math.floor(m));
    System.out.println("Rounded value of 6.25 up to highest Integer="+Math.ceil(m));
    System.out.println("Truncated value of 6.25="+Math.rint(m));
    System.out.println("Exponent Value of 6.25="+Math.exp(m));
}
}
