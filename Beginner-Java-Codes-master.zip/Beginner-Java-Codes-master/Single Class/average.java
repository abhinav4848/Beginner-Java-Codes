class average
{
public static void main(String args[])
{
int a=5,b=3,c=10,d=2,e=13;
int f=(a+b+c+d+e);
float g=f/5;
System.out.println(g);
}
}