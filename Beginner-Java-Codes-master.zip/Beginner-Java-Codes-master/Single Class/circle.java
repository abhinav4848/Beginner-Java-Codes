//To find the area and circumference of a circle using assignment statement. Nos. mentioned from Before.
public class circle
{
    public static void main(String args[])
    {
        int r;
        float ar,c;ar=0;c=0;
        r=15;
        ar=22/7*r*r;
        c=2*22/7*r;
        System.out.println("The radius of the Circle="+r+" cm");
        System.out.println("The Area of the Circle="+ar+" sq. cm");
        System.out.println("The Circumference of the Circle="+c+" cm");
    }
}