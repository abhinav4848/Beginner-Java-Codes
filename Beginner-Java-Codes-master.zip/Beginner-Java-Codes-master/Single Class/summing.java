//To find the sum of two nos. using assignment statement. Nos. Mentioned from before.
public class summing
{
public static void main(String args[])
{
int a,b,c;c=0;
a=25;b=30;
c=a+b;
System.out.println("The Sum of the two nos. 25 and 30 is="+c);
}
}