//To find the sum of a series of 10 nos.
public class sumseries
{
public static void main(String args[])
{
int a;
int s;s=0;
for(a=1;a<=10;a++)
s=s+a;
System.out.println("The sum of 1, 2, 3, 4, 5, 6, 7, 8, 9 and 10 is="+s);
}
}