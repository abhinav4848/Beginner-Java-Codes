//My name,class etc. displayed
public class ak
{
    public static void main(String args[])
    {
        System.out.println("Name   :Abhinav.");
        System.out.println("Class  :IX-B.");
        System.out.println("Roll   :12.");
        System.out.println("Subject:PC.");
        System.out.print("School :St. Paul's School.");
    }
}